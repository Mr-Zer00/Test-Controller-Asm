package Sobrecarga;

public class Carro {
  
    public void acelerarCarro(Carro carro) {}
    
}
