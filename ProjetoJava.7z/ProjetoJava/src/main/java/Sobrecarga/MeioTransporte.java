package Sobrecarga;
public class MeioTransporte {
    
    public void inserir(Object obj) {
    
        if(obj instanceof Veiculo) {
            System.err.println("Carro inserido");
        }
        
        if(obj instanceof Caminhao) {
            System.err.println("caminhão inserido");
        }
        
    }
    
    public void alterar(Object obj) {
        
        if(obj instanceof Veiculo) {
            System.err.println("Carro Inserido");
        }
        
    }

    @Override
    public String toString() {
        return "MeioTransporte{" + '}';
    }

    public MeioTransporte() {
    }
    
    
}