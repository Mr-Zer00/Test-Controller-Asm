package Sobrecarga;

import static java.awt.Event.F1;

public class Personagem {
    
    class Carro {}
    class Motocicleta {}
    class Caminhonete {}
    
    public void acelerarCarro(Carro carro) {}  
    public void acelerarMotocicleta(Motocicleta motocicleta) {}  
    public void acelerarCaminhonete(Caminhonete caminhonete) {} {
    
}
    
    class Barrichello extends Personagem{ 
    public void acelerar(F1 f1) {}
    
}
