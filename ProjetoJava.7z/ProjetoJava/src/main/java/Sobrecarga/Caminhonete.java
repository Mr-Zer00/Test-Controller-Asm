package Sobrecarga;

public class Caminhonete {
 
    public void acelerar(Caminhonete caminhonete, Carro carro)
     public void acelerar(Caminhonete caminhonete)
             public void acelerar(F1 f1)
    
}
