package Sobrecarga;

import static java.awt.Event.F1;
import static javafx.scene.input.KeyCode.F1;

public class Barrichello extends Personagem {
    public void acelerar(F1 f1)
    
    
}
