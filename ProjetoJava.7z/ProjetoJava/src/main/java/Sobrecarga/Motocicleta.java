package Sobrecarga;

public class Motocicleta {
  
    public void acelerarMotocicleta(Motocicleta motocicleta) {}
    
}
