package Exercicio3;
public class TesteVetores {

    public static void main(String[] args) {
        // Inicializa a classe de leitura dos vetores
        LerVetores v = new LerVetores(10, 7);

        // Carrega os dados no primeiro vetor
        v.loadVetA();

        // Carrega os dados no segundo vetor
        v.loadVetB();

        // Exibe o primeiro vetor
        System.out.println("Primeiro vetor:");
        v.showVetA();
        System.out.println();

        // Exibe o segundo vetor
        System.out.println("Segundo vetor:");
        v.showVetB();
        System.out.println();

        UnirVetores un = new UnirVetores();

        un.addVetor(v.getVetA());
        un.addVetor(v.getVetB());

        // Exibe o vetor de união
        System.out.println("Vetor de União:");
        un.showUnion();

    }
}