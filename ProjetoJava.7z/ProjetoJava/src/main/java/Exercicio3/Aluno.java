
package Exercicio3;

public class Aluno{

    private final int matricula;
    private final String nome;
    private final double n1;
    private final double n2;
    private final double trabalho;
    
    public Aluno(int m, String n, double n1, double n2, double t){
        matricula = m;
        nome = n;
        this.n1 = n1;
        this.n2 = n2;
        trabalho = t;
    }
    
    public double media(){
        return ((n1+n2)*2.5+trabalho*2)/7;
    }
    
    public double aFinal(){
        double media = media();
        if(media<2.5 || media>=5)
            return 0;
            
        return 10-media; 
    }

    void exclui(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}