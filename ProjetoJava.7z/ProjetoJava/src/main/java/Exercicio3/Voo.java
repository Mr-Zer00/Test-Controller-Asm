package Exercicio3;

public class Voo {

    public static void main(String[] args) {
     
    }

    private int numero;
    private String dia;
    private String mes;
    private int ano;

    public Voo(int numero,String dia,String mes,int ano){

        this.numero = numero;
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }

    public int proximoLivre(){
        return numero;
    }

    public boolean verifica(int numero){

        return true;
    }

    public boolean ocupa(int numero){

        return true;
    }

    public boolean vagas(int numero){

        return true;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }


}
