package Exercicio3;

import java.util.Scanner;

public class LerVetores {

    private final int vetA[];
    private final int vetB[];
    private final Scanner ent;

    /**
     * Inicializa a classe de leitura de dois vetores
     * @param sizeA Tamanho do primeiro vetor
     * @param sizeB Tamanho do segundo vetor
     */
    LerVetores(int sizeA, int sizeB) {
        // Inicializa a entrada de dados
        ent = new Scanner(System.in);
        // Inicializa os vetores
        vetA = new int[sizeA];
        vetB = new int[sizeB];
    }

    /**
     * Carrega os valores no vetor A, interagindo com o usuário
     */
    public void loadVetA() {
        for (int i = 0; i < vetA.length; i++) {
            System.out.print("Digite o " + (i + 1) + "º valor do primeiro vetor: ");
            vetA[i] = ent.nextInt();
        }

    }

    /**
     * Carrega os valores no vetor B, interagindo com o usuário
     */
    public void loadVetB() {
        for (int i = 0; i < vetB.length; i++) {
            System.out.print("Digite o " + (i + 1) + "º valor do segundo vetor: ");
            vetB[i] = ent.nextInt();
        }
    }

    /*
     * Exibe o vetor A, usando "for avançado"
     */
    public void showVetA() {
        for (int element : vetA) {
            System.out.printf("%d\t", element);
        }
        System.out.println();
    }

    /**
     * Exibe o vetor A, usando "for avançado"
     */
    public void showVetB() {
        for (int element : vetB) {
            System.out.printf("%d\t", element);
        }
        System.out.println();
    }

    /**
     * Retorna o primeiro vetor
     * @return
     */
    public int[] getVetA() {
        return vetA;
    }

    /**
     * Retorna o segundo vetor
     * @return
     */
    public int[] getVetB() {
        return vetB;
    }
}