package Exercicio3;

import java.io.*;

public class VetorOrdenado
{
public static void main (String args[])
{
int aux, i, j, x[] = new int [10];
byte temp, y[] = new byte [10];

System.out.println ("Digite 10 valores para ordenar seu vetor: ");


try
{	

for (i = 0; i < 10; i++)		
aux = System.in.read (y); /* aqui se eu coloco o aux como vetor dá um erro ! */

	
for (i = 0; i < 10; i++)
	for (j = i + 1; j < 10; j++)
		
		if (y[i] < y[j])
		{
			temp = y[i]; 	
			y[i] = y[j];
			y[j] = temp;					

		}

System.out.println ("Seu Vetor Ordenado de forma Decrescente: ");

for (i = 0; i < 10; i++){		
	x[i] = (int) y[i];// typecast
	System.out.println (x[i]);
}



}

catch (IOException e) {

}

}
}