
package Exercicio3;

import javax.swing.JOptionPane;

public class Data {

    private int dia, mes, ano;

    public static void main(String[] args) {
        Data dataUm = new Data("26/10/2013");
        Data dataDois = new Data("26/10/2013a");
        Data dataTres = new Data("01/01/0001");
        System.out.println(dataUm);
        comparaDatas(dataDois, dataTres);
    }

    public Data(String dtCompleta) {
        dia = 1;
        mes = 1;
        ano = 1;
        if (10 == dtCompleta.length()) {
            if (dtCompleta.charAt(2) == '/' && dtCompleta.charAt(5) == '/') {
                dia = Integer.valueOf(dtCompleta.substring(0, 2));
                mes = Integer.valueOf(dtCompleta.substring(3, 5));
                ano = Integer.valueOf(dtCompleta.substring(6, 10));
            }
        }
    }

    @Override
    public String toString() {
        return dia + "/" + mes + "/" + ano;
    }

    public static void comparaDatas(Data dtUm, Data dtDois) {
        if (dtUm.getDia() == dtDois.getDia() && dtUm.getMes() == dtDois.getMes() && dtUm.getAno() == dtDois.getAno()) {
            JOptionPane.showMessageDialog(null, "As datas são iguais!");
        }
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
}