package pkginterface;

public class Circulo implements FormaGeometrica
{
    private double raio;

    public double getRaio() {
        return raio;
    }

    public Circulo(double raio) 
    {
        this.raio = raio;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }
    private static final double PI = 3.14;

    public double area() 
    {
        return(PI * raio * raio);
    }

    public double comprimento() 
    {
        return(2 * PI * raio);
    }

    public double lado() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
