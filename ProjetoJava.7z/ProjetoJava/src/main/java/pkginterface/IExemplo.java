package pkginterface;


public interface IExemplo {
    public void metodo1();
    public void metodo2();
}
