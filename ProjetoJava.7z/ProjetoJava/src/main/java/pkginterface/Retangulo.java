package javaapplication1;

import pkginterface.FormaGeometrica;

public class Retangulo implements FormaGeometrica
{
    private double comprimentoRetangulo;

    public Retangulo(double comprimentoRetangulo, double altura) 
    {
        this.comprimentoRetangulo = comprimentoRetangulo;
        this.altura = altura;
    }
    private double altura;

    public double getComprimentoRetangulo() {
        return comprimentoRetangulo;
    }

    public void setComprimentoRetangulo(double comprimentoRetangulo) {
        this.comprimentoRetangulo = comprimentoRetangulo;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    public double area()
    {
        return(altura * comprimentoRetangulo);
    }
   
    public double comprimento()
    {
        return (comprimentoRetangulo);
    }
}
