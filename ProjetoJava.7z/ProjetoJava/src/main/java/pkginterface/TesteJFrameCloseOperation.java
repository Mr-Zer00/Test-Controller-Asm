package pkginterface;
import javax.swing.*;
public class TesteJFrameCloseOperation extends JFrame {
    
    public TesteJFrameCloseOperation()
    {
        super("Exemplo JFrame com default close operation");
        setSize(300, 300);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public static void main (String[] args)
    {
        TesteJFrameCloseOperation frame = new TesteJFrameCloseOperation();
    }
}
