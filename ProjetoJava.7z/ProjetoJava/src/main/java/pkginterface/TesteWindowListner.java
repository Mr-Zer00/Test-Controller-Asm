package pkginterface;
import javax.swing.*;
public class TesteWindowListner {
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Exemplo");
        frame.setSize(300, 300);
        frame.setVisible(true);
        
        TrataWindow tw = new TrataWindow();
        frame.addWindowListener(tw);
        
    }
    
}
