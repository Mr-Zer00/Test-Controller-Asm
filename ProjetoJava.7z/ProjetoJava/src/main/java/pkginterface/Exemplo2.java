/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface;

/**
 *
 * @author 1191528470
 */
public class Exemplo2 implements IExemplo{
    public void metodo1() {
        System.out.println("Executando metodo1() do Ex2...");
    }
    public void metodoN (){
        System.out.println("Executando metodoN () do Ex2...");
    }

    @Override
    public void metodo2() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
