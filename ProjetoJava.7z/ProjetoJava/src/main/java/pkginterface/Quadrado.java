package javaapplication1;

import pkginterface.FormaGeometrica;

public class Quadrado implements FormaGeometrica
{
    private double lado;
    
    public double area()
    {
        return (lado * lado);
    }

    public Quadrado(double lado) {
        this.lado = lado;
    }

    public double getLadoquadrado() {
        return lado;
    }

    public void setLadoquadrado(double lado) {
        this.lado = lado;
    }
    
    public double comprimento()
    {
        return (lado);
    }
}
