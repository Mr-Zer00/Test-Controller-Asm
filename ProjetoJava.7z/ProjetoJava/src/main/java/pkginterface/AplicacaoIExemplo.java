package javaapplication1;
import java.util.Scanner;
import pkginterface.Circulo;
import pkginterface.FormaGeometrica;

public class AplicacaoIExemplo {
    
    public static void main(String[] args){
    
    Scanner sc = new Scanner(System.in);
    System.out.print("Lado do quadrado: ");
    double lado = sc.nextDouble();
    System.out.print("Raio do círculo: ");
    double raio = sc.nextDouble();
    System.out.print("Altura do retangulo: ");
    double altura = sc.nextDouble();
    System.out.print("Comprimento do retangulo: ");
    double comprimentoRetangulo = sc.nextDouble();
    
    FormaGeometrica fc = new Circulo(raio);
    FormaGeometrica fq = new Quadrado(lado);
    FormaGeometrica fr = new Retangulo(altura, comprimentoRetangulo);
    
     System.out.print("Area do circulo: \n"+ fc.area());
     System.out.print("\nComprimento do circulo: \n"+ fc.comprimento());
     System.out.print("\nArea do quadrado: \n"+ fq.area());
     System.out.print("\nComprimento do quadrado: \n"+fq.comprimento());
     System.out.print("\nArea do retangulo: \n"+ fr.area());
     System.out.print("\nComprimento do retangulo: \n"+fr.comprimento());

    
    }
   
}