/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface;

/**
 *
 * @author 1191528470
 */
public class Exemplo implements IExemplo {
    public void metodo1() {
        System.out.println("Executando metodo1()...");
    }
    public void metodoN (){
        System.out.println("Executando metodoN ()...");
    }

    @Override
    public void metodo2() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
