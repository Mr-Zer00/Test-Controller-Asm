
package pkginterface;
import java.awt.event.*;
import javax.swing.JOptionPane;
public class TrataWindow implements WindowListener {

        
    public void windowClosing(WindowEvent e){
        System.exit(0);
        
        
    }
    public void windowIconified(WindowEvent e) {
    JOptionPane.showMessageDialog(null,
            "Teste dialogo ERROR_MESSAGE",
            "Mesnagem de erro",
            JOptionPane.ERROR_MESSAGE);
    }
    public void windowOpened(WindowEvent e) {
     JOptionPane.showMessageDialog(null,
            "Teste dialogo INFORMATION_MESSAGE",
            "Mesnagem de informativa",
            JOptionPane.INFORMATION_MESSAGE);   
        
    }
    public void windowClosed(WindowEvent e) {
     JOptionPane.showMessageDialog(null,
            "Teste dialogo WARNING_MESSAGE",
            "Mesnagem de alerta",
            JOptionPane.WARNING_MESSAGE); 
    
    }
    public void windowDeiconified(WindowEvent e) {
     JOptionPane.showMessageDialog(null,
            "Teste dialogo QUESTION_MESSAGE",
            "Mesnagem de questionamento",
            JOptionPane.QUESTION_MESSAGE); 
    
    }
    public void windowActivated(WindowEvent e) {
     JOptionPane.showMessageDialog(null,
            "Teste dialogo INFORMATION_MESSAGE",
            "Mesnagem de informativa",
            JOptionPane.ABORT); 
    
    }
    public void windowDeactivated(WindowEvent e) {
    JOptionPane.showMessageDialog(null,
            "Teste dialogo INFORMATION_MESSAGE",
            "Mesnagem de informativa",
            JOptionPane.DEFAULT_OPTION);
    }        
}
