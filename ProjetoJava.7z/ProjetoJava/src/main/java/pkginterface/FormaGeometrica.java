package pkginterface;

public interface FormaGeometrica 
{
    public double area();
    public double comprimento();
}
