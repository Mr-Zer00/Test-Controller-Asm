/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CirculosCalculos;

import CirculoAtributos.CirculoVO;

public class CirculoBO {

    /**
     *
     * @param circuloVO
     * @return
     */
    public double CalculaDiametro(CirculoVO circuloVO)
    {
        return Math.pow(circuloVO.getRaio(),2);
        
    }
    
    public double CalcularArea(CirculoVO circuloVO)
    {
        return Math.PI*Math.pow(circuloVO.getRaio(),2);
    }
    
    public double CalcularCircuferencia(CirculoVO circuloVO)
    {
        return 2*Math.PI*(circuloVO.getRaio());
    }
    
   public void exibirdados(CirculoVO circuloVO)
   {
       System.out.println("Diametro "+this.CalculaDiametro(circuloVO));
       System.out.println("Area "+this.CalcularArea(circuloVO));
       System.out.println("Circuferencia "+this.CalcularCircuferencia(circuloVO));
       
   }
}
