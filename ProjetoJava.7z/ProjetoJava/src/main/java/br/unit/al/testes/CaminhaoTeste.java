
package br.unit.al.testes;

import br.unit.al.model.CaminhaoBO;
import br.unit.al.model.CaminhaoVO;

public class CaminhaoTeste {
    
    public static void main(String [] args){
        
        CaminhaoVO caminhaoVO = new CaminhaoVO();
        
        CaminhaoVO caminhaoVO1 = new CaminhaoVO(258.65, 8);
        
        CaminhaoVO caminhaoVO2 = new CaminhaoVO(258.45, 8, "Modelo TRUCK,");
        
        caminhaoBO.exibirDados(caminhaoVO);
        caminhaoBO.exibirDados(caminhaoVO1);
        caminhaoBO.exibirDados(caminhaoVO2);
    }
    
}
