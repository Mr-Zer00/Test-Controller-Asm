
package br.unit.al.testes;

import br.unit.al.model.Circulo;

public class Circulo extends Circulo {

    public Circulo(int i) {
    
    }
    
}