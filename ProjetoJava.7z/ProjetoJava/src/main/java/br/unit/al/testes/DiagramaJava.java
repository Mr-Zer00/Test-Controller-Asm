/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.unit.al.testes;

import br.unit.al.model.Disciplina;

/**
 *
 * @author João Carlos
 */
public class DiagramaJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Disciplina disciplina1 = new Disciplina();
        disciplina1.setNome("Programação Orientada a Objetos");
        disciplina1.setCargaHoraria(-10);
        
        System.out.println(disciplina1.getNome());
        System.out.println(disciplina1.getCargaHoraria());
        
    }
    
}
