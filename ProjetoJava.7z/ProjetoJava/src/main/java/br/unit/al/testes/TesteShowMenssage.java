
package br.unit.al.testes;
import javax.swing.*;
public class TesteShowMenssage {
    
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,
                "SIMULAÇÃO CANCELADA",
                "Monsters ",
                JOptionPane.PLAIN_MESSAGE);{
        
    }
        JOptionPane.showMessageDialog(null,
                "DESLIGAMENTO EM 60Seg",
                "Monsters SA",
                JOptionPane.PLAIN_MESSAGE);{
        
        
    }
        
        JOptionPane.showMessageDialog(null,
                "SIMULAÇÃO CANCELADA",
                "Monsters SA",
                JOptionPane.WARNING_MESSAGE);{
        
        
    }
        
                JOptionPane.showMessageDialog(null,
                "SIMULAÇÃO CANCELADA",
                "Monsters SA",
                JOptionPane.QUESTION_MESSAGE);
                
    }
    
}
