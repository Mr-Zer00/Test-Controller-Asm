
package br.unit.al.model;

public class CaminhaoBO {
    
}
