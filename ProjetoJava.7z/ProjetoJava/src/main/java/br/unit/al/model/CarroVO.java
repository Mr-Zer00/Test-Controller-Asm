
package br.unit.al.model;

public class CarroVO {
   
    private String eixo;
    
    private double capacidade;
    
    private String modelo;
    
    private String chasi;
    
}
