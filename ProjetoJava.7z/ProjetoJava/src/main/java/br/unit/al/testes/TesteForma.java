package br.unit.al.testes;
import br.unit.al.model.Circulo;

public class TesteForma {
    
    public static void main (String args[]) {
        
    }
    
    FormaGeometrica f = new FormaGeometrica();
    f.imprime();
    
    Circulo c = new Circulo(5) {};
    c.imprime();
    
}
