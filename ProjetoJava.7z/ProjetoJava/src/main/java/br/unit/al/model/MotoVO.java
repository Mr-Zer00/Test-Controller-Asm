
package br.unit.al.model;

public class MotoVO {
    
}
