
package br.unit.al.testes;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class TesteConfirmDialog {
    public static void main (String[] args){
        JFrame frame = new JFrame("MONSTROS SA");
        frame.setSize(800, 800);
         frame.setVisible(true);
         
         int op = JOptionPane.showConfirmDialog(frame,
                 "Deseja finalizar a execução?",
                 "Saída",
                 JOptionPane.YES_NO_OPTION,
                 JOptionPane.QUESTION_MESSAGE);
         
         if (op==0)
             JOptionPane.showMessageDialog(null,
                     "SIMULAÇÃO CANCELADA",
                     "Saída",
                     JOptionPane.PLAIN_MESSAGE);
         else 
             JOptionPane.showMessageDialog(null,
                     "CODIGO 23-19",
                     "Retorna",
                     JOptionPane.PLAIN_MESSAGE);{
    }
                     JOptionPane.showMessageDialog(null,
                     "hackeado",
                     "Retorna",
                     JOptionPane.PLAIN_MESSAGE);
    }
    
}
