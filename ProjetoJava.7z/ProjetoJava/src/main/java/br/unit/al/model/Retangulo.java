package br.unit.al.model;

public class Retangulo extends FormaGeomatrica {

    @Override
    public double area() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private double base, altura;
    public Retangulo(double base, double altura) {
        
    }
    
    public void setBase(double base) {
        
    }
           if (base<0) this.base = 0;
           else this.base = base; {
  
    
}
  
           public void setAltura(double altura){
               
           }
           
           if ( altura < 0) this.altura = 0;
           else this.altura = altura
           
}
