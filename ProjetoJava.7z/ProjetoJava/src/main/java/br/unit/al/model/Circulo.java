package br.unit.al.model;

public abstract class Circulo extends FormaGeomatrica
{
    
private double raio;

public void setRaio (double raio)
{
    
    if(raio<0) this.raio = 0;
    else this.raio = raio; {
    
}
    
    public Circulo (double raio);
    {
        setRaio(raio);
    }

  
    }

}