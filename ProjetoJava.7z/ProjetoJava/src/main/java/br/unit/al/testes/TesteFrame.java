package br.unit.al.testes;

import javax.swing.*;
public class TesteFrame {
    
    public static void main(String[] arge){
        JFrame fr = new JFrame("Exemplo");
        fr.setSize(400, 300);
        fr.setVisible(true);
    }
    
}
