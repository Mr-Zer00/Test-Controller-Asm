/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.unit.al.testes;

import pkginterface.Exemplo;
import pkginterface.Exemplo2;
import pkginterface.IExemplo;

/**
 *
 * @author 1191507928
 */
public class AplicacaoTeste {
    public static void main(String[]arg){
    IExemplo ex = new Exemplo2();
        ex.metodo1();
        ex.metodo2();
    
    
    IExemplo e = new Exemplo();
        e.metodo1();
        e.metodo2();
    }
    
}
