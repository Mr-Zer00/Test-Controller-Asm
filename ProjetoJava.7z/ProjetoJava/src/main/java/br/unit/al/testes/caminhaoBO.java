
package br.unit.al.testes;

import br.unit.al.model.CaminhaoVO;

class caminhaoBO {

    static void exibirDados(CaminhaoVO caminhaoVO1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
