/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CirculoTeste;

import CirculoAtributos.CirculoVO;
import CirculosCalculos.CirculoBO;

/**
 *
 * @author 1191507928
 */
public class CirculoTE {
    
    public static void main(String [] args)
    {
        CirculoBO circuloBO = new CirculoBO();
        CirculoVO circuloVO = new CirculoVO(5);
        System.out.println(" Raio: " + circuloVO.getRaio());
        circuloBO.exibirdados(circuloVO);
        
        circuloVO.setRaio(-15);
        
        circuloBO.exibirdados(circuloVO);
    
        
    }
    
}
