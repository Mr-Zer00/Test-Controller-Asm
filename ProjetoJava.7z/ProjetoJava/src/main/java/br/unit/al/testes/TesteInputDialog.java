package br.unit.al.testes;

import javax.swing.JOptionPane;

public class TesteInputDialog {
    
public static void main(String[] args){
    String s = JOptionPane.showInputDialog(null, 
            "Digite um numero:",
    "Entrada de dados",
    JOptionPane.QUESTION_MESSAGE);{
    
}
    JOptionPane.showMessageDialog(null, 
            "O numero inserido foi: "+s,
            "Saida",
            JOptionPane.PLAIN_MESSAGE);
}   
    
}
