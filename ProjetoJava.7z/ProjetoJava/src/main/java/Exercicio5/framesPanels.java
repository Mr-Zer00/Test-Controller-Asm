package Exercicio5;

import javax.swing.JFrame;

public class framesPanels {
    public static void main(String[] args) {
 JFrame janela = new JFrame("Meu primeiro frame em Java");
        janela.setSize(300,200);
 janela.setVisible(true);
    }
}