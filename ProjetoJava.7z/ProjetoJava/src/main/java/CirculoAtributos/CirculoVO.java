/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CirculoAtributos;

/**
 *
 * @author 1191507928
 */
public class CirculoVO
{
    private double raio;
    
    public CirculoVO(double r)
    {
        setRaio(r);
    }

    public double getRaio() {
        return raio;
    }

    public void setRaio(double r) {
        if(r < 0)
            System.out.println("O raio e menor que zero");
        else
            raio = r;
    }
    
    
    
}
