
package br.unit.al.model;

import java.util.ArrayList;

public class Nome {
   private String nome;
   private String endereço;
    
    }
    
    

