
package Exercicio2;

public interface InterfaceCliente {
 
    public String nome();
    public String enderec();
    public String cpf();
    public String cnpj();
    public double bonus();
    public String validade();
}
